#include <rooms/voice_room.hpp>

ww::voice_room::voice_room(std::string const &name) : room_interface(name) {

}

void ww::voice_room::start() {

}
