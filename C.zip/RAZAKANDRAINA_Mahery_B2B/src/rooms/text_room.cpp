#include <rooms/text_room.hpp>

using namespace ww;

text_room::text_room(std::string const &name) : room_interface(name) {

}

void text_room::start() {

}
