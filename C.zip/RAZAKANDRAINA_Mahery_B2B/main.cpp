#include <iostream>

int main(int argc, char *argv[]) {
    std::cout << "Werewolf server" << std::endl;

    return 0;
}
